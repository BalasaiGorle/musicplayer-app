"use client";

const Toast = () => {
  return <div>Toast</div>;
};

export default Toast;
