'use client'

const ImageSlider = () => {
  return <nav>

  </nav>;
};

export default ImageSlider;
