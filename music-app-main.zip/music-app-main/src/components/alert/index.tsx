import React from "react";

const Alert = () => {
  return <div>AlertAuth</div>;
};

export default Alert;
